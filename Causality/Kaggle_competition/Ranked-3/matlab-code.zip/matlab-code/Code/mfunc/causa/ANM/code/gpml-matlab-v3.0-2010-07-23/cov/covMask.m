function [A, B] = covMask(cov, hyp, x, z)

% Apply a covariance function to a subset of the dimensions only. The subset can
% either be specified by a 0/1 mask by a boolean mask or by an index set.
%
% This function doesn't actually compute very much on its own, it merely does
% some bookkeeping, and calls another covariance function to do the actual work.
%
% The function was suggested by Iain Murray, 2010-02-18 and is based on an
% earlier implementation of his dating back to 2009-06-16.
%
% Copyright (c) by Carl Edward Rasmussen and Hannes Nickisch, 2010-06-20.
%
% See also COVFUNCTIONS.M.

mask = cov{1}(:);                         % either a binary mask or an index set
cov = cov(2);                                 % covariance function to be masked
nh_string = feval(cov{:});    % number of hyperparameters of the full covariance

if max(mask)<2 && length(mask)>1, mask = boolean(mask); end   % convert 1/0->T/F
if islogical(mask), D = sum(mask); else D = length(mask); end % masked dimension
if nargin<3, A = num2str(eval(nh_string)); return; end    % number of parameters

if eval(nh_string)~=length(hyp)                          % check hyperparameters
  error('number of hyperparameters does not match size of masked data')
end

if nargin==3
  A = feval(cov{:}, hyp, x(:,mask));
elseif nargout==2                                 % compute test set covariances
  [A, B] = feval(cov{:}, hyp, x(:,mask), z(:,mask));
else                                                 % compute derivative matrix
  A = feval(cov{:}, hyp, x(:,mask), z);
end