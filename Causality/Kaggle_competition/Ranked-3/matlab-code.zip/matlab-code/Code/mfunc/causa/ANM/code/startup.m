cd 'gpml-matlab-v3.0-2010-07-23'
startup
cd ..
addpath('fasthsic');
addpath('dags');
addpath('experiments');
