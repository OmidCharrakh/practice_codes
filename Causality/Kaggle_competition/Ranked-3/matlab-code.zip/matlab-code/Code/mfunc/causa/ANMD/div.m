function result=div(a,b)
result=(a-mod(a,b))./b;