%addpath('../../../code-extern/netlab');
%
% Copyright (c) 2010  Oliver Stegle, Joris Mooij
% All rights reserved.  See the file COPYING for license terms.
%
run('../gpml-matlab-v3.1-2010-09-27/startup');
addpath('../exportfig');
addpath('../fasthsic');
addpath('../gpi');
addpath('../mixturecode');
