For the cause-effect pair challenge, 
lingam.m was moved to lingam_orig.m
and the lingam function was modified to return a value f that is positive if A->B and negative is A<-B.
the prune.m function was renames prunit.m

