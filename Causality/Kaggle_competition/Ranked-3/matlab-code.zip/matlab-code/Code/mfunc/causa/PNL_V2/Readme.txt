%%%Use of constrained nonlinear ICA for distinguishing cause from effect%%%

To see how to use the package, please type 
    help CauseOrEffect_fun
in the MATLAB command window.
