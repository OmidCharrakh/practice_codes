function code_version()

fprintf('Code version: March 26, 2013\n');
